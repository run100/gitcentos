#define SPH_SVN_TAG "rel201"
#define SPH_SVN_REV 2792
#define SPH_SVN_REVSTR "2792"
#define SPH_SVN_TAGREV "r2792"
#define SPHINX_TAG "-beta"
